#include"App.h"

int main()
{
	//Time t,t1;
	//while (true)
	//{
	//	t.setTime();
	//	t1.setTime();
	//	cout << t+t1 << endl;
	//	cout << t - t1 << endl;
	//}
	App newapp;
	newapp.start();
}