﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.DAL.Entities
{
    public class Author2Book
    {
        public int AuthorId { get; set; }
        public int BookId { get; set; }
        //public Author Author { get; set; } = null;
        //public Book Book { get; set; } = null;
    }
}
