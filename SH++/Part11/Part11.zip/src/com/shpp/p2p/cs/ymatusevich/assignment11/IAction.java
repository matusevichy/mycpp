package com.shpp.p2p.cs.ymatusevich.assignment11;


/**
 * Interface for operators and functions
  */
public interface IAction {
    Double calculate(Double leftNumber, Double rightNumber);
}
