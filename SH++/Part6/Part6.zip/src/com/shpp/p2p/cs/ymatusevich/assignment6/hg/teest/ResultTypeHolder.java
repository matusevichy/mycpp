package com.shpp.p2p.cs.ymatusevich.assignment6.hg.teest;

public class ResultTypeHolder {

    public enum ResultType {SUCCESS, FAILURE, EXCEPTION}

}

