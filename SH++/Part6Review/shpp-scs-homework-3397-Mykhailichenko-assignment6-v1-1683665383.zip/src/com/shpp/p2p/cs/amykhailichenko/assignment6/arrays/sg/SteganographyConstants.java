package com.shpp.p2p.cs.amykhailichenko.assignment6.arrays.sg;

public interface SteganographyConstants {
    int CANVAS_WIDTH = 400;
    int CANVAS_HEIGHT = 300;
}
