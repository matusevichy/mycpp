package com.shpp.p2p.cs.achuchko.assignment6.sg;

public interface SteganographyConstants {
    int CANVAS_WIDTH = 400;
    int CANVAS_HEIGHT = 300;
}
