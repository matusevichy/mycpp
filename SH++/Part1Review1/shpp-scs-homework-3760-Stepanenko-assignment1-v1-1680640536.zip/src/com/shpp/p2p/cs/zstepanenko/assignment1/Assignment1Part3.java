package com.shpp.p2p.cs.zstepanenko.assignment1;

import com.shpp.karel.KarelTheRobot;

/*Assignment1Part3 class extends KarelTheRobot class
 * so that Karel finds the midpoint of the Southern edge
 * of the world.
 * I am aware that my program is not working and a bad mark is
 * inevitable, but I am still sending it hoping that in cooperation
 * with a reviewer, I will be able to find the missing piece of a code.
 */
public class Assignment1Part3 extends KarelTheRobot {
    @Override
    public void run() throws Exception {
        findTheLengthOfSouthernEdge();
        findMidPointOfSouthernEdge();

    }

    /*In order to find the middle of the Southern edge of his world,
     * Karel has to firstly, figure out its length and secondly, come up
     * with an idea how to appear in the midpoint.
     */
    private void findTheLengthOfSouthernEdge() throws Exception {
        putBeeper();
        while (frontIsClear()) {
            move();
            putBeeper();
        }
    }

    /* Precondition: Karel is in the Southwestern corner of the world
     * facing East.
     * Result: Karel reached the endpoint of the Southern edge and is facing East.
     * To embrace the length of the Southern edge, Karel marks the start point of his
     * journey with a beeper and moves forward placing one beeper into each cell until
     * he reaches the wall.
     */
    private void findMidPointOfSouthernEdge() throws Exception {
        handlingEdgeCases();
        while (???){
            handlingNextPairOfSteps();
        }
        if (noBeepersPresent()) {
            move();
            turnAround();
            move();
            putBeeper();
        }
    }
    /* Precondition: Karel is in the Southeastern corner of the world
     * facing East;
     * Result: Karel has found and marked the midpoint of the Southern edge.
     * To perform this task Karel has to handle edge cases and go down to cases
     * in the middle. Middle steps are iterative and here is the problem that I can't
     * figure out yet. What condition in the brackets won't make the cycle endless?
     * When I learn it and the cycle will break, next actions will logically complete
     * the program. When Karel picks up the last beeper, he will make one move, turn around,
     * make another move and put beeper right in the center from where he has just taken it.
     */

    private void handlingEdgeCases() throws Exception {
        turnAround();
        pickBeeper();
        while (frontIsClear()) {
            move();
        }
        turnAround();
        pickBeeper();
    }

    /* Precondition: Karel is in the Southeastern corner of the world
     * facing East;
     * Result: Karel removed edge beepers and is facing East.
     * To find the centre of the Southern edge Karel chose to remove beepers
     * one by one from each end. Edge beepers are easier to remove as soon as
     * their positions are constant.
     * For this, Karel turns around, picks the last beeper, moves forward until he
     *  faces the wall, turns around and extracts the first beeper.
     */
    private void handlingNextPairOfSteps() throws Exception {
        while (noBeepersPresent()) {
            move();
        }
        if (beepersPresent()) {
            pickBeeper();
        }
        while (frontIsClear()) {
            move();
        }
        turnAround();
        while (noBeepersPresent()) {
            move();
        }
        if (beepersPresent()) {
            pickBeeper();
        }
    }

    /* Precondition: Karel is in the Southwestern corner of the world
     * facing East, there is no beeper under him;
     * Result: Karel removed all beepers.
     * The peculiarity of middle cases is that before picking a beeper,
     * Karel has to skip empty cells. This leads to extra "while"-cycle
     * which serves to resolve the dilemma and helps Karel move until he
     * encounters a beeper. When a beeper is reached, the robot picks it
     * and moves until wall. Then Karel turns around and repeats the same
     * set of actions.
     */

    private void turnAround() throws Exception {
        turnLeft();
        turnLeft();
    }
    /* As soon as Karel doesn't know how to turn around,
     * this method teaches him do this by performing two turns leftwards.
     */
}

