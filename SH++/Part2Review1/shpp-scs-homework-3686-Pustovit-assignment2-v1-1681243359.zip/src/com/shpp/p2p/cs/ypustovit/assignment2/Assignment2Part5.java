package com.shpp.p2p.cs.ypustovit.assignment2;


import acm.graphics.GRect;
import com.shpp.cs.a.graphics.WindowProgram;

import java.awt.*;


public class Assignment2Part5 extends WindowProgram {

    //These constants are needed to regulate application width and height.
    public static final int APPLICATION_WIDTH = 800;
    public static final int APPLICATION_HEIGHT = 800;

    /* The number of rows and columns in the grid, respectively. */
    private static final int NUM_ROWS = 3;
    private static final int NUM_COLS = 5;

    /* The width and height of each box. */
    private static final double BOX_SIZE = 40;

    /* The horizontal and vertical spacing between the boxes. */
    private static final double BOX_SPACING = 10;

    public void run() {
        //Due to use NUM_COLS and NUM_ROWS constants in calculations,
        //you can easily change quantity of boxes.
        double xStart = calculateStartX(NUM_COLS, BOX_SIZE, BOX_SPACING);
        double yStart = calculateStartY(NUM_ROWS, BOX_SIZE, BOX_SPACING);

        //Draws illusion from left to right.
        for (int i = 0; i < NUM_ROWS; i++) {
            for (int j = 0; j < NUM_COLS; j++) {
                //Draws one square of the illusion.
                drawSquare(xStart + (BOX_SIZE + BOX_SPACING) * j,
                        yStart + (BOX_SIZE + BOX_SPACING) * i, BOX_SIZE, Color.BLACK);
            }
        }
    }

    /**
     * Calculates coordinate x of the starting point of the illusion.
     * It specifies the upper-left corner of the bounding box containing that illusion.
     *
     * @param numCols    Number of columns of the illusion.
     * @param boxSize    Size of each box of the illusion.
     * @param boxSpacing Length of space between boxes.
     * @return Coordinate x of the first left upper corner box.
     */
    private double calculateStartX(int numCols, double boxSize, double boxSpacing) {
        //These conditions are needed to check if number of columns even or odd.
        if (numCols % 2 == 0) {
            return getWidth() / 2.0 - numCols / 2 * (boxSize + boxSpacing) - boxSpacing / 2;
        } else {
            return getWidth() / 2.0 - numCols / 2 * (boxSize + boxSpacing) - boxSize / 2;
        }
    }

    /**
     * Calculates coordinate y of the starting point of the illusion.
     * It specifies the upper-left corner of the bounding box containing that illusion.
     *
     * @param numRows    Number of rows of the illusion.
     * @param boxSize    Size of each box of the illusion.
     * @param boxSpacing Length of space between boxes.
     * @return Coordinate y of the first left upper corner box.
     */
    private double calculateStartY(int numRows, double boxSize, double boxSpacing) {
        //These conditions are needed to check if number of rows even or odd.
        if (numRows % 2 == 0) {
            return getWidth() / 2.0 - numRows / 2 * (boxSize + boxSpacing) - boxSpacing / 2;
        } else {
            return getWidth() / 2.0 - numRows / 2 * (boxSize + boxSpacing) - boxSize / 2;
        }
    }

    /**
     * Draws a square with given x and y coordinate, size and color.
     * The coordinates specify the upper-left corner of the square.
     *
     * @param x     The x coordinate of the upper-left corner of the square.
     * @param y     The y coordinate of the upper-left corner of the square.
     * @param size  The width and height of the square.
     * @param color The color of the square.
     */
    private void drawSquare(double x, double y, double size, Color color) {
        GRect rect = new GRect(x, y, size, size);
        rect.setFilled(true);
        rect.setColor(color);
        add(rect);
    }

}
