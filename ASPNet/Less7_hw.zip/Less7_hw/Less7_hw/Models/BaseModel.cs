﻿namespace Less7_hw.Models
{
    public class BaseModel
    {
        public int Id { get; set; }
    }
}
