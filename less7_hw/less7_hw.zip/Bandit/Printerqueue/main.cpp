#include"App.h"

int main()
{
	App newapp(10);
	newapp.Start();
}