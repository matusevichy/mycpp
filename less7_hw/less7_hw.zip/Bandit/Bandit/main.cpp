#include"App.h"

int main()
{
	srand(time(0));
	App newapp;
	newapp.Start();
}