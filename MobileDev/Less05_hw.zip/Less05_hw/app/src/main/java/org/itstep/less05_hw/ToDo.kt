package org.itstep.less05_hw

data class ToDo (val id: Int, val text: String)